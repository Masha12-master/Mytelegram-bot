# Magic Voice Bot
Text-to-speech Telegram bot.

## Install
pip install -r requirements.txt

## Run
Put your token inside bot.py:

TOKEN = "YOUR_TOKEN_HERE"

Run:
python bot.py
