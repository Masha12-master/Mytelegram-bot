import telebot

TOKEN = "YOUR_TOKEN_HERE"
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "Assalomu alaykum! Men Magic Voice botman. Matn yuboring — ovoz qilib beraman.")

@bot.message_handler(content_types=['text'])
def text_to_voice(message):
    from gtts import gTTS
    tts = gTTS(text=message.text, lang='en')
    tts.save("voice.ogg")
    with open("voice.ogg", "rb") as v:
        bot.send_voice(message.chat.id, v)

bot.infinity_polling()
